import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {Strategy} from './main.ts';

const hello={type:'hello',protocol:'agent-fun/bars-replay/v1',seed:'1',symbols:[{symbol:'CBBTC',mint:'11111111111111111111111111111111',price_scale:5,qty_scale:8}],capital:{quote:'USDC',quote_scale:6,quote_units:'1000000000'},bar_interval:'1m',first_close_ms:60000,caps:{max_open_positions:1,max_orders_per_bar:16,max_weight_bps:10000,shorts:false,leverage:false},fees:{fee_bps:4,slippage_bps:2,min_notional_quote_units:'1000000'},latency_bars:1};
const batch=(seq,price,positions=[])=>({type:'batch',seq,t:(seq+1)*60000,bars:[{symbol:'CBBTC',t:(seq+1)*60000,o:String(price),h:String(price),l:String(price),c:String(price),v:null,o_depth:['1000000000000'],c_depth:['1000000000000']}],fills:[],account:{cash_quote_units:'1000000000',positions,equity_quote_units:'1000000000'}});
test('first allocation retains a cash reserve and obeys the exposure cap',()=>{
 const s=new Strategy();s.onHello({...hello,caps:{...hello.caps,max_weight_bps:5000}});
 const orders=s.onBatch(batch(0,100000));assert.equal(orders.length,1);assert.equal(orders[0].notional_quote_units,'500000000');
});
test('warm-up, missing bars and insufficient cash cannot order',()=>{
 const s=new Strategy();s.onHello({...hello,warmup_bars:5});assert.deepEqual(s.onBatch(batch(0,100000)),[]);
 assert.deepEqual(s.onBatch({...batch(8,100000),bars:[]}),[]);
 const poor=batch(9,100000);poor.account.cash_quote_units='99';assert.deepEqual(s.onBatch(poor),[]);
});
test('trailing stop exits all units and prevents a churned re-entry',()=>{
 const s=new Strategy();s.onHello(hello);s.onBatch(batch(0,100000));
 const pos=[{symbol:'CBBTC',qty:'100000000',cost_quote_units:'650000000'}];
 assert.deepEqual(s.onBatch(batch(1,110000,pos)),[]);
 const exit=s.onBatch(batch(2,106000,pos));assert.equal(exit[0].side,'sell');assert.equal(exit[0].qty,'100000000');
 // A rejected exit is retried even if the next close rebounds above the trigger.
 assert.equal(s.onBatch(batch(3,109000,pos))[0].side,'sell');
 assert.deepEqual(s.onBatch(batch(4,108000)),[]);
});
test('a gap between signal and confirmed position does not invent a trailing loss',()=>{
 const s=new Strategy();s.onHello(hello);s.onBatch(batch(0,100000));
 const pos=[{symbol:'CBBTC',qty:'100000000',cost_quote_units:'650000000'}];
 assert.deepEqual(s.onBatch(batch(1,96000,pos)),[]);
 assert.equal(s.onBatch(batch(2,93000,pos))[0].side,'sell');
});
test('wire outputs one reply per batch, none for hello or done; repeated runs match',()=>{
 const stream=[hello,batch(0,100000),batch(1,100100),{type:'done',seq:2,reason:'end_of_data',account:batch(1,100100).account}].map(x=>JSON.stringify(x)).join('\n')+'\n';
 const run=()=>spawnSync(process.execPath,['main.ts'],{cwd:import.meta.dirname,input:stream,encoding:'utf8'});
 const a=run(),b=run();assert.equal(a.status,0,a.stderr);assert.equal(a.stdout,b.stdout);const replies=a.stdout.trim().split('\n').map(JSON.parse);assert.equal(replies.length,2);assert.deepEqual(replies.map(x=>x.seq),[0,1]);assert(replies.every(x=>x.type==='reply'));
});
test('truncated input fails instead of silently succeeding',()=>{
 const input=[hello,batch(0,100000)].map(JSON.stringify).join('\n')+'\n';
 const r=spawnSync(process.execPath,['main.ts'],{cwd:import.meta.dirname,input,encoding:'utf8'});
 assert.equal(r.status,1);assert.match(r.stderr,/before done/);
});
test('duplicate or out-of-order sequence numbers fail',()=>{
 for(const seq of [0,4]){
  const input=[hello,batch(0,100000),batch(seq,100000)].map(JSON.stringify).join('\n')+'\n';
  const r=spawnSync(process.execPath,['main.ts'],{cwd:import.meta.dirname,input,encoding:'utf8'});
  assert.equal(r.status,1);assert.match(r.stderr,/out of order/);
 }
});
