// Deterministic, long-only paper strategy. No network, credentials or real orders.
import { createInterface } from 'node:readline';

// A low-turnover comparison policy: cash reserve, bounded allocation and a trailing stop.
// It deliberately avoids fitting a large set of parameters to one public day.
export class Strategy {
  hello:any;
  peak=0;
  opened=false;
  stopped=false;
  onHello(message:any){this.hello=message;}
  onBatch(message:any){
    const symbol=this.hello.symbols[0];
    const bar=message.bars.find((b:any)=>b.symbol===symbol.symbol);
    if(!bar||message.seq<(this.hello.warmup_bars??0)) return [];
    const price=Number(bar.c);
    if(!(price>0&&Number.isFinite(price))) return [];
    const held=message.account.positions.find((p:any)=>p.symbol===symbol.symbol&&BigInt(p.qty)>0n);
    if(held){
      if(!this.opened){this.opened=true;this.peak=price;}
      else this.peak=Math.max(this.peak,price);
      if(this.stopped||price<this.peak*.975){
        this.stopped=true;
        return [{side:'sell',client_id:`risk-exit-${message.seq}`,symbol:symbol.symbol,qty:String(held.qty),max_slippage_bps:120}];
      }
      return [];
    }
    if(this.opened||this.stopped) return [];
    const cash=BigInt(message.account.cash_quote_units);
    const maxWeight=BigInt(message.account.equity_quote_units)*BigInt(this.hello.caps.max_weight_bps)/10000n;
    const reserveStake=cash*65n/100n;
    const stake=reserveStake<maxWeight?reserveStake:maxWeight;
    if(stake<BigInt(this.hello.fees.min_notional_quote_units)||this.hello.caps.max_open_positions<1||this.hello.caps.max_orders_per_bar<1) return [];
    return [{side:'buy',client_id:`allocate-${message.seq}`,symbol:symbol.symbol,notional_quote_units:String(stake),max_slippage_bps:120}];
  }
}

async function run(){
  const strategy=new Strategy();
  let receivedHello=false;
  let receivedDone=false;
  let nextSeq=0;
  const lines=createInterface({input:process.stdin,crlfDelay:Infinity});
  for await(const line of lines){
    if(Buffer.byteLength(line)>1048576) throw new Error('Input line exceeds limit');
    if(!line.trim()) continue;
    const message=JSON.parse(line);
    if(message.type==='hello'){
      if(receivedHello||message.protocol!=='agent-fun/bars-replay/v1') throw new Error('Invalid hello');
      strategy.onHello(message);receivedHello=true;
    } else if(message.type==='batch'){
      if(!receivedHello) throw new Error('Batch before hello');
      if(!Number.isSafeInteger(message.seq)||message.seq!==nextSeq) throw new Error('Batch sequence is out of order');
      nextSeq++;
      process.stdout.write(JSON.stringify({type:'reply',seq:message.seq,orders:strategy.onBatch(message)})+'\n');
    } else if(message.type==='done'){
      if(!receivedHello||message.seq!==nextSeq) throw new Error('Invalid done sequence');
      receivedDone=true;break;
    }
    else throw new Error('Unknown message type');
  }
  if(!receivedDone) throw new Error('Input ended before done');
}
if(import.meta.url===new URL(process.argv[1],'file:').href || process.argv[1]?.replaceAll('\\','/').endsWith('/main.ts')){
  run().catch(error=>{console.error(error.message);process.exitCode=1;});
}
